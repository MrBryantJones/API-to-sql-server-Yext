USE [Marketing]
GO

/****** Object:  Schema [staging]    Script Date: 10/24/2025 4:36:36 PM ******/
DROP SCHEMA [staging]
GO

/****** Object:  Schema [staging]    Script Date: 10/24/2025 4:36:36 PM ******/
CREATE SCHEMA [staging]
GO


