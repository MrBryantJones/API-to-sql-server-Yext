USE [Marketing]
GO

/****** Object:  Schema [bi]    Script Date: 10/24/2025 4:36:30 PM ******/
DROP SCHEMA [bi]
GO

/****** Object:  Schema [bi]    Script Date: 10/24/2025 4:36:30 PM ******/
CREATE SCHEMA [bi]
GO


