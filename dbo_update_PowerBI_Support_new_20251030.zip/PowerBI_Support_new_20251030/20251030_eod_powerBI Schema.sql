USE [Marketing]
GO

/****** Object:  Schema [powerBI]    Script Date: 10/29/2025 4:36:30 PM ******/
DROP SCHEMA [powerBI]
GO

/****** Object:  Schema [powerBI]    Script Date: 10/29/2025 4:36:30 PM ******/
CREATE SCHEMA [powerBI]
GO