# Changelog

## [Unreleased]
- Initial scaffold: module shell, SQL staging/fact, CI lint + tests, config template.
