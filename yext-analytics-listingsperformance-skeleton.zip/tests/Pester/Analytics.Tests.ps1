Describe 'Yext Analytics ListingsPerformance module' {
    It 'resolves a sane window' {
        $cfg = Import-PowerShellDataFile -Path './config/yext_config.psd1'
        $w = Get-YextAnalyticsWindow -Config $cfg
        ($w.Start -as [datetime]) | Should -BeLessThan ($w.End -as [datetime])
    }
}
