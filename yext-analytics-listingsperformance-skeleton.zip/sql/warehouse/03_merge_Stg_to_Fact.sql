MERGE dbo.FactYextListingsPerformance AS T
USING (
    SELECT [Date], EntityId, MetricCode, Value
    FROM dbo.YextAnalytics_ListingsPerformance_Stg S
) AS S
ON (T.[Date] = S.[Date] AND ISNULL(T.EntityId,'') = ISNULL(S.EntityId,'') AND T.MetricCode = S.MetricCode)
WHEN MATCHED AND T.Value <> S.Value THEN
  UPDATE SET T.Value = S.Value, T.LastUpdated = SYSUTCDATETIME()
WHEN NOT MATCHED BY TARGET THEN
  INSERT ([Date], EntityId, MetricCode, Value) VALUES (S.[Date], S.EntityId, S.MetricCode, S.Value);
GO
