CREATE TABLE IF NOT EXISTS dbo.FactYextListingsPerformance (
    [Date]       DATE         NOT NULL,
    EntityId     NVARCHAR(64) NULL,
    MetricCode   NVARCHAR(64) NOT NULL,
    Value        BIGINT       NOT NULL,
    LastUpdated  DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
    CONSTRAINT PK_FactYextListingsPerformance PRIMARY KEY ([Date], ISNULL(EntityId,''), MetricCode)
);
GO
