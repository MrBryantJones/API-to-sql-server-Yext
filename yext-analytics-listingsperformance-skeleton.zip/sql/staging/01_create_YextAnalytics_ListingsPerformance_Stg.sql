CREATE TABLE IF NOT EXISTS dbo.YextAnalytics_ListingsPerformance_Stg (
    RunId            UNIQUEIDENTIFIER NOT NULL,
    PulledAtUtc      DATETIME2(3)     NOT NULL DEFAULT SYSUTCDATETIME(),
    PeriodStart      DATE             NOT NULL,
    PeriodEnd        DATE             NOT NULL,
    [Date]           DATE             NOT NULL,
    EntityId         NVARCHAR(64)     NULL,
    MetricCode       NVARCHAR(64)     NOT NULL,
    Value            BIGINT           NOT NULL,
    RowHash          VARBINARY(8000)  NOT NULL,
    CONSTRAINT PK_YA_ListingsPerf_Stg PRIMARY KEY (RunId, [Date], ISNULL(EntityId,''), MetricCode)
);
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = 'UX_YA_ListingsPerf_NaturalKey')
BEGIN
  CREATE UNIQUE INDEX UX_YA_ListingsPerf_NaturalKey
  ON dbo.YextAnalytics_ListingsPerformance_Stg([Date], ISNULL(EntityId,''), MetricCode);
END
GO
