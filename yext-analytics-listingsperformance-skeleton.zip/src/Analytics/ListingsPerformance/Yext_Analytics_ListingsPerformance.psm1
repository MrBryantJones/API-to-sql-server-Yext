function Get-YextAnalyticsWindow {
    param([hashtable] $Config)
    $lag  = [int]$Config.Analytics.DataLagDays
    $span = [int]$Config.Analytics.LastNDays
    $end  = if ($Config.Analytics.EndDateOverride) { [datetime]$Config.Analytics.EndDateOverride } else { (Get-Date).ToUniversalTime().Date.AddDays(-$lag) }
    $start = $end.AddDays(-$span + 1)
    if ($Config.Analytics.Mode -eq 'Backfill' -and $Config.Analytics.StartDate) {
        $start = [datetime]$Config.Analytics.StartDate
    }
    if ($Config.Analytics.Mode -eq 'OneShot' -and $Config.Analytics.StartDate) {
        $start = [datetime]$Config.Analytics.StartDate
        if ($Config.Analytics.EndDateOverride) { $end = [datetime]$Config.Analytics.EndDateOverride }
    }
    return [pscustomobject]@{ Start = $start.ToString('yyyy-MM-dd'); End = $end.ToString('yyyy-MM-dd') }
}

function Invoke-YextAnalyticsReport {
    [CmdletBinding()]
    param([hashtable] $Config, [hashtable] $Window)
    $base = $Config.BaseUrl.TrimEnd('/')
    $ver  = $Config.Version
    $uri  = "$base/v2/accounts/me/analytics/reports?v=$ver"
    $body = @{
        metrics    = $Config.Analytics.Metrics
        dimensions = $Config.Analytics.Dimensions
        dateRange  = @{ start = $Window.Start; end = $Window.End }
        limit      = $Config.Analytics.PageSize
    }
    $all = @()
    $page = $null
    do {
        if ($page) { $body.pageToken = $page } else { $body.Remove('pageToken') | Out-Null }
        $resp = Invoke-YextApi -Uri $uri -Method POST -Body $body -TimeoutSec $Config.TimeoutSec
        if ($resp?.response?.rows) { $all += $resp.response.rows }
        $page = $resp?.response?.nextPageToken
    } while ($page)
    return $all
}

function Convert-YextAnalyticsRows {
    param([object[]] $Rows)
    $out = foreach ($r in $Rows) {
        # Expected row format: { "metrics": { "METRIC": value, ... }, "dimensions": { "DATE": "...", "ENTITY": "..." } }
        $date  = $r.dimensions.DATE
        $entity = $r.dimensions.ENTITY
        foreach ($k in $r.metrics.PSObject.Properties.Name) {
            [pscustomobject]@{
                Date       = [datetime]$date
                EntityId   = [string]$entity
                MetricCode = [string]$k
                Value      = [long]$r.metrics.$k
            }
        }
    }
    return $out
}

function Write-YextAnalyticsStaging {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object[]] $Rows,
        [Parameter(Mandatory)][hashtable] $Config,
        [Parameter(Mandatory)][guid] $RunId,
        [Parameter(Mandatory)][hashtable] $Window
    )
    # Minimal example: use System.Data.SqlClient bulk copy
    $connStr = $Config.Sql.ConnectionString
    $tbl = New-Object System.Data.DataTable
    foreach ($c in @('RunId','PulledAtUtc','PeriodStart','PeriodEnd','Date','EntityId','MetricCode','Value','RowHash')) {
        [void]$tbl.Columns.Add($c)
    }
    $periodStart = [datetime]$Window.Start
    $periodEnd   = [datetime]$Window.End
    $pulledAt = [datetime]::UtcNow
    foreach ($r in $Rows) {
        $hashInput = "{0}|{1}|{2}" -f $r.EntityId,$r.Date.ToString('yyyy-MM-dd'),$r.MetricCode
        $hash = [System.Text.Encoding]::UTF8.GetBytes($hashInput)
        $row = $tbl.NewRow()
        $row.RunId       = $RunId
        $row.PulledAtUtc = $pulledAt
        $row.PeriodStart = $periodStart
        $row.PeriodEnd   = $periodEnd
        $row.Date        = $r.Date
        $row.EntityId    = $r.EntityId
        $row.MetricCode  = $r.MetricCode
        $row.Value       = $r.Value
        $row.RowHash     = $hash
        $tbl.Rows.Add($row)
    }
    $tableName = "[{0}].[YextAnalytics_ListingsPerformance_Stg]" -f $Config.Sql.StagingSchema

    $cn = New-Object System.Data.SqlClient.SqlConnection $connStr
    $cn.Open()
    try {
        $bc = New-Object System.Data.SqlClient.SqlBulkCopy $cn
        $bc.DestinationTableName = $tableName
        foreach ($c in $tbl.Columns) { $bc.ColumnMappings.Add($c.ColumnName, $c.ColumnName) | Out-Null }
        $bc.WriteToServer($tbl)
    } finally {
        $cn.Close()
    }
}

function Run-YextListingsPerformance {
    [CmdletBinding()]
    param([string] $ConfigPath = "./config/yext_config.psd1")
    $cfg = Import-PowerShellDataFile -Path $ConfigPath
    $win = Get-YextAnalyticsWindow -Config $cfg
    $runId = [guid]::NewGuid()

    Write-Host "Yext Analytics window: $($win.Start) to $($win.End)  RunId=$runId"
    $rows = Invoke-YextAnalyticsReport -Config $cfg -Window $win
    if (-not $rows) { Write-Warning "No rows returned."; return }
    $flat = Convert-YextAnalyticsRows -Rows $rows
    Write-YextAnalyticsStaging -Rows $flat -Config $cfg -RunId $runId -Window $win
    Write-Host "Completed. Rows: $($flat.Count)"
}

Export-ModuleMember -Function Get-YextAnalyticsWindow,Invoke-YextAnalyticsReport,Convert-YextAnalyticsRows,Write-YextAnalyticsStaging,Run-YextListingsPerformance
