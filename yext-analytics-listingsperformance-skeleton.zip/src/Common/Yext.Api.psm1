function Invoke-YextApi {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string] $Uri,
        [ValidateSet('GET','POST')][string] $Method = 'GET',
        [hashtable] $Body,
        [int] $TimeoutSec = 120
    )
    $headers = @{
        "Content-Type" = "application/json"
    }
    # Prefer API Key header or query param per your existing approach
    if ($env:YEXT_API_KEY) {
        $headers["Authorization"] = "Bearer $($env:YEXT_API_KEY)"
    }

    $params = @{
        Uri         = $Uri
        Method      = $Method
        Headers     = $headers
        TimeoutSec  = $TimeoutSec
        ErrorAction = 'Stop'
    }
    if ($Method -eq 'POST' -and $Body) {
        $params.Body = ($Body | ConvertTo-Json -Depth 8)
    }

    try {
        return Invoke-RestMethod @params
    }
    catch {
        throw "Yext API error: $($_.Exception.Message)"
    }
}
Export-ModuleMember -Function Invoke-YextApi
