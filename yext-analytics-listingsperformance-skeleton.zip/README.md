# Yext Analytics – Listings Performance Module

This repository contains a drop‑in, config‑driven PowerShell module and SQL assets to ingest **Listings Impressions, Clicks, and Profile Views** from the **Yext Analytics API** and land them in SQL Server.

## Components
- **PowerShell** (src/): API windowing, POST report call, pagination, retries, normalization, and staging load
- **SQL** (sql/): staging table, fact table, and MERGE
- **Config** (config/): non‑secret operational settings
- **CI** (.github/workflows): lint + unit tests via PSScriptAnalyzer & Pester

## Quick start
1. Clone and set your secrets as environment variables (see below).
2. Update `config/yext_config.psd1` as needed.
3. Run locally:
   ```powershell
   Import-Module ./src/Common/Yext.Api.psm1 -Force
   Import-Module ./src/Analytics/ListingsPerformance/Yext_Analytics_ListingsPerformance.psm1 -Force
   Run-YextListingsPerformance -ConfigPath ./config/yext_config.psd1
   ```
4. Deploy SQL objects in `sql/staging` and `sql/warehouse`.
5. Set up a scheduled run (Task Scheduler or runner) for ongoing incremental loads.

## Secrets (env vars)
- `YEXT_API_KEY` (or OAuth token flow if applicable)
- `SQL_CONN_STR` (e.g., `Server=...;Database=...;Trusted_Connection=yes;`)

> Do **not** commit secrets. Use environment variables, CI secrets, or a vault.

## License
MIT
